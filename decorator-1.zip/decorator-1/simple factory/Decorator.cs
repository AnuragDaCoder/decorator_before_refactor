﻿

namespace decoratorpattern
{
    public interface ICakeDecorator
    {
        void Decorate(string message);
    }

    public class CakeDecorator : ICakeDecorator
    {
        private readonly ICake _cake;

        public CakeDecorator(ICake cake)
        {
            _cake = cake;
        }
        public void Decorate(string message)
        {
            _cake.AddLayer(message);
        }
    }

}
