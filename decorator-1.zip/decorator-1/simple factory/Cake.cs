﻿

namespace decoratorpattern
{
    public interface ICake
    {
        void AddLayer(string layer);
        void ShowAllLayers();
    }

    public class StrawberryCake : ICake
    {
        private List<string> layers = new ();
        public void AddLayer(string layer)
        {
            layers.Add (layer);
        }

        public void ShowAllLayers()
        {
            Console.WriteLine("This is Strawberry Cake");

            layers.ForEach(layer =>
           {
               Console.WriteLine(layer);
           });
        }
    }

    public class BlackForestCake : ICake
    {
        private List<string> layers = new();
        public void AddLayer(string layer)
        {
            layers.Add(layer);
        }

        public void ShowAllLayers()
        {
            layers.ForEach(layer =>
            {
                Console.WriteLine("This is BlackForestCake Cake");
                Console.WriteLine($"layer -->", layer);
            });
        }
    }
}
